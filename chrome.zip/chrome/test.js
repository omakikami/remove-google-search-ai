function Fkai(){

    document.querySelectorAll("div.Kevs9.SLPe5b").forEach(div =>div.remove());

}

window.addEventListener("load",Fkai);

const cambio = new MutationObserver(Fkai);
cambio.observe(document.body,  {childList: true, subtree:true});