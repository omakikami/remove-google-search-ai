chrome.declarativeNetRequest.updateDynamicRules({
    addRules: [{
        "id": 1,
        "priority": 1,
        "action": { "type": "block" },
        "condition": {
            "urlFilter": "*.js",
            "resourceTypes": ["script"]
        }
    }],
    removeRuleIds: [1]
});

chrome.action.onClicked.addListener((tab) => {
    chrome.tabs.reload(tab.id);
});
